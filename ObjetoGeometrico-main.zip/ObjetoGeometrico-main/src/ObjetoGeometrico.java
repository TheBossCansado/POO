abstract public class ObjetoGeometrico {
    protected String cor;

    public abstract double getArea();
    public abstract double getPerimetro();
}
